using System;
using UnityEngine;

/* not working, kinda similar to Eagle creation code
[CreateAssetMenu(fileName = "AnimalData", menuName = "Custom/Animal", order = 0)]
public class AnimalData : ScriptableObject
{
    [field:SerializeField] public AnimalStats Stats { get; private set; }
    //insert prefab in below field in Unity Editor
    [field:SerializeField] public GameObject AnimalVisuals { get; private set; }
}


[Serializable]
public struct AnimalStats
{
    public string name;
    public float speed;
}
*/